﻿
using System.Security.AccessControl;
using System.Transactions;

namespace Assignment_3
{
/*
    1. CDAC YCP has certain number of batches.each batch has certain number of students
         accept number of batches. for each batch accept number of students.
         create an array to store mark for each student (1 student has only 1 subject mark)
        accept the marks.
        display the marks.
*/

    internal class First
    {
/*
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Number of batches : ");

            
            
            int numberOfBatches = int.Parse(Console.ReadLine());


            int[][] batches = new int[numberOfBatches][]; 

            for(int i = 0; i < numberOfBatches ; i++)
            {

                Console.WriteLine("Enter number of students for batch " + (i + 1));

                batches[i] = new int[int.Parse(Console.ReadLine())];

                
                for(int j = 0 ; j < batches[i].Length ; j++)
                {
                    Console.WriteLine("Enter marks of student " + (j + 1) + " for batch " + (i + 1));
                    batches[i][j] = int.Parse(Console.ReadLine()); 
                }
            }


            Console.WriteLine("Marks of students per batch");


            for (int i = 0; i < numberOfBatches; i++)
            {

                Console.WriteLine("Batch : " + (i + 1) + " Marks");

                


                for (int j = 0; j < batches[i].Length; j++)
                {
                    Console.WriteLine("student " + (j + 1) + ": " + batches[i][j]);
                    
                }
            }




        }*/
    }
}

/*Common language runtime*/
/*Common type system*/
