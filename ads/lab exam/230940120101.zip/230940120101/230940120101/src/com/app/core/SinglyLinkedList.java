package com.app.core;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

// custom class singly linked list
// for int type of data
public class SinglyLinkedList {
	
	
	// class variables of singly ll class
	
	// head pointer of type List Node
	 
	private ListNode head;
	
	
	public SinglyLinkedList() {
		this.head = null;
	
	}
	
	
	// Singly Linked List functionality
	
	
	
    // 1) functionality 1
	
	// method to add element x such that list remains sorted
	
	
	
	public void add(int x) {
		
		// create a newNode with data
		
		ListNode newNode = new ListNode(x);
		
		// in case of list is empty means head is null
		if(head == null) {
			head = newNode;
		}else {
			// otherwise insert the node at appropriate position so than list remain sorted
			
			// if element at head position is greater than newNode element
			// make newNode as a head node
			if(head.data > newNode.data) {
				
				newNode.next = head;
				head = newNode;
			}else {
				
				// create a temp pointer 
				// iterate through the list till the appropriate index comes to insert the newNode
				
				ListNode temp = head;
				
				while(temp.next != null && temp.next.data < newNode.data) {
					temp = temp.next;
				}
				
				newNode.next = temp.next;
				temp.next = newNode;
			}
		}
		
	}
	
	
	// 2) functionality 2
	
	// method to remove all list of X from the current list
	
	public void removeAll(List<Integer> x) {
		
		
		// store the elements of the elements in list in the HashSet for faster retrieval 
		
		Set<Integer> set = new HashSet<>(x);
		
		// move the head pointer till the head.data is not in the set
		
		while(head != null && set.contains(head.data)) {
			head = head.next;
		}
		
		// to remove the node from the list, we require the track of previous node
		// create temp pointer to have the track of previous node
		
		ListNode temp = head;
		
		// at this point temp.data is never gonna be in the list of elements to be removed (bcz we had handled this in above while loop)
		
		while(temp != null && temp.next != null) {
			
			// 2 possibilities exists here
			// temp.next.data is in set
			// and
			// temp.next.data is not in set
			
			if(set.contains(temp.next.data)) {
				
				temp.next = temp.next.next;
				
			}else {
				
				temp = temp.next;
			}
			
			
			
		}
		
	}
	
	
	// 3) functionality 3
	
	// method to find the index of x in the list from the beginning. Return -1 if elementis not found in the list.
	
	public int find(int x) {
		
		// if list is empty -> return -1
		
		if(head == null) {
			return -1;
		}
		
		// traverse through the complete linked list and check that whether x is present or not
		
		ListNode temp = head;
		
		int index = 0;
		while(temp != null) {
			
			if (temp.data == x) {
				return index;
			}
			
			// update the pointers
			
			temp = temp.next;
			index++;
		}
		
		return -1;
	}
	
	// 4) functionality 4
	
	// method which returns comma separated elements from start to end
	
	@Override
	public String toString() {
		
		StringBuilder string = new StringBuilder();
		
		
		string.append("[");
		
		ListNode temp = head;
		
		while(temp != null) {
			
			if(temp.next == null) {
				string.append(temp.data);
			}else {
				string.append(temp.data + ", ");
			}
			
			temp = temp.next;
		}
		
		
		string.append("]");
		
		return string.toString();
		
	}
	
	
	
	
	
	
	
	
	// private internal class ListNode]
	
	private class ListNode {
		
		// data members of List Node
		
		private int data;
		private ListNode next;
		
		
		public ListNode(int data) {
			this.data = data;
			this.next = null;
		}
		
		
	}
	

}
