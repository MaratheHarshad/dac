package com.app.tester;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.app.core.SinglyLinkedList;

public class Test {

//	Note:

//	for custom data type, must override the equals method (for removeAll() to identify the equal objects)

	public static void main(String[] args) {

		try (Scanner sc = new Scanner(System.in)) {

			// create a instance of SinglyLinkedList

			SinglyLinkedList ll = new SinglyLinkedList();

			while (true) {

				try {
					
					System.out.println("************************************************************");
					System.out.println("Enter choice : ");
					System.out.println("1. To add element in the list");
					System.out.println("2. Create list to be removed from original list");
					System.out.println("3. To find the element index in the list");
					System.out.println("4. To print the list");
					System.out.println("5. Exit");
					System.out.println("************************************************************");

					int choice = sc.nextInt();

					switch (choice) {

					case 1: {
						add(sc, ll);
						break;
					}

					case 2: {
						removeAll(sc, ll);
						break;
					}

					case 3: {
						find(sc, ll);
						break;
					}

					case 4: {

						System.out.println(ll);
						break;
					}

					case 5: {
						System.exit(1);

					}

					default: {
						System.out.println("Invalid choice ");

					}
					}

				} catch (Exception e) {

					System.out.println("Exception in inner try-catch block");
					e.printStackTrace();
				}

			}

		} catch (Exception e) {

			System.out.println("Error occured");
			e.printStackTrace();
		}

	}

	// static helper methods for switch

	// static method to add the element

	public static void add(Scanner sc, SinglyLinkedList ll) {
		System.out.println("Enter the element to be added in the list: ");
		ll.add(sc.nextInt());
	}

	// method to remove list of elements
	public static void removeAll(Scanner sc, SinglyLinkedList ll) {
		List<Integer> list = new ArrayList<>();

		boolean flag = true;

		while (flag) {

			System.out.println("Enter Choice");
			System.out.println("1. Add the element in the list to be removed from the original linked list");
			System.out.println("2. Stop");

			switch (sc.nextInt()) {

			case 1: {
				System.out.println("Enter element");
				list.add(sc.nextInt());
				break;
			}
			case 2: {
				flag = false;
				break;
			}
			default: {
				System.out.println("Invalid choice ");

			}
			}
		}

		ll.removeAll(list);

	}

	// method to find element in linked list
	public static void find(Scanner sc, SinglyLinkedList ll) {

		System.out.println("Enter the element to be find index in the list: ");
		System.out.println(ll.find(sc.nextInt()));

	}
}
