package com.app.core;

public class SinglyLL {
	
//	class members
//	head
//	tail
	
//	ll functionality
	
//	add
//	remove
//	remove at index
//	
	
	
//	require inner class Node
//	with data members
//	next ptr of same type
//	
}
