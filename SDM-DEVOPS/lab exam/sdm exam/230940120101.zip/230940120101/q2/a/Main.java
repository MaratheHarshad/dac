public class Main {
    public static void main(String[] args) {

        int number1 = 10;
        int number2 = 7;
        int number3 = 8;

        int sum = number1 + number2 + number3;

        System.out.println("sum of largest 3 numbers is: " + sum);

    }
}
