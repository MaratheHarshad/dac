#include<iostream>
using namespace std;

class Basic
{  
    int i;
    int j;

    


};
int main()
{

    return 0;
}