#include<iostream>
using namespace std;

void function1(int number){
    cout<<"Insid function1"<<endl;
    cout<<"number is : "<<number<<endl;
}

void greet(){
    cout<<"JAY SHREE RAM";
}