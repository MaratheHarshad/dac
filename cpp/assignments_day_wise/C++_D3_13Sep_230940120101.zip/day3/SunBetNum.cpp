// Find sum of all the numbers between two positive integers N And M including N And M.
// if numbers are 4 And 6 Output will be 4+5+6 = 15.

#include<iostream>
using namespace std;

int main()
{
    int M,N;

    cout<<"enter M And N"<<"\n";
    cin>>M;
    cin>>N;

    int iSum = 0;

    iSum = 0 + 
    M = 4
    N = 6

    while(M <= N){
        iSum += M;
        M++;
    }

    cout<<"Sum is : "<<iSum<<endl;

    return 0;
}