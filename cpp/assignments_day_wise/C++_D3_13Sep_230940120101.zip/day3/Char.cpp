//Accept the character from user aand print its askii value

#include<iostream>
using namespace std;


int main()
{
    char ch;
    cout<<"Enter the character : ";
    cin>>ch;

    cout<<"Ascii of character is : "<<(int)(ch)<<endl;

    return 0;
}