package com.app.core;

public enum Size {
	
	S, M, L, XL

}
