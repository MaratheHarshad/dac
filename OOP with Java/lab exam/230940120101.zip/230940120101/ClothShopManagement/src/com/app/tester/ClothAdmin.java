package com.app.tester;

import static com.app.utils.ClothUtils.populateList;
import static com.app.utils.ClothUtils.updateDiscount;
import static com.app.utils.ClothUtils.validateAndUpdateStock;
// user defined utilities
import static com.app.utils.ClothValidation.validateAll;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.app.core.Cloth;

public class ClothAdmin {

	public static void main(String[] args) {

//		creating scanner class instance to wrap std in
//		try-with-resources ( autoclose the autoclosable objects)\

		try (Scanner sc = new Scanner(System.in);) {
//
			List<Cloth> clothList = populateList();

			boolean exit = false;

			while (!exit) {

				try {
					
					displayMenu();

					
					switch (sc.nextInt()) {
					case 1:

						// Add new Cloth

						// take details of cloth to be entered

						System.out.println(
								"Enter Category (MENS_TSHIRT, MENS_SHIRTS, WOMENS_JEANS) , Stock quantity, Size, Price, Brand (VAN_HEUSEN, PUMA, LEE) , Color, Dicounts");
						Cloth cloth = validateAll(sc.next(), sc.nextInt(), sc.next(), sc.nextDouble(), sc.next(),
								sc.next(), sc.nextDouble(), clothList);
						clothList.add(cloth);
						System.out.println("cloth added : " + cloth);
						
						break;
						
						
					case 2:
						
						// update stock of a cloth
						System.out.println("Enter cloth id, and stock to update stock of a cloth");
						cloth = validateAndUpdateStock(sc.nextInt(), sc.nextInt(), clothList);
						System.out.println("Stock updated for cloth : " + cloth);
						
						break;
						
						
					case 3:
						
//						Set discount (in %) for all the clothes of given Category and Brand
						System.out.println("Enter discount, category and  brand");
						updateDiscount(sc.nextDouble(), sc.next(), sc.next(), clothList);
						System.out.println("Discounts updated");
						
						break;
						
						
					case 4:
						
//						Remove Clothes which are out of stock for last 2 months
						
						Iterator<Cloth> it = clothList.iterator();
						
						while(it.hasNext()) {
							cloth = it.next();
							// if last stock update date + 2 months is before today means (clothes are out of stock for last 2 months and more)
							// if we want exactly 2 months then equals is used
							if(cloth.getStock() == 0 && cloth.getStockUpdateDate().plusMonths(2).isBefore(LocalDate.now())) {
								it.remove();
							}
						}
						break;
						
					case 5: 
						System.out.println("Cloth which are out of stock today");
						clothList.stream().filter(c -> c.getStock() == 0 && c.getStockUpdateDate().equals(LocalDate.now())).forEach(System.out::println);
						break;
						
					case 6:
						// display all 
						clothList.forEach(System.out::println);
						break;

					default:
						break;
					}

				} catch (Exception e) {
					e.printStackTrace();

				}
			}

		} catch (Exception e) {

		}

	}

	private static void displayMenu() {
		
		System.out.println("********************** MENU ***************************");
		System.out.println("1. Add new Cloth");
		System.out.println("2. Update stock of a Cloth");
		System.out.println("3. Set discount (in %) for all the clothes of given Category and Brand");
		System.out.println("4. Remove Clothes which are out of stock for last 2 months");
		System.out.println("5. List out Clothes which are out of stock today");
		System.out.println("6. Display all");
		System.out.println("Enter Choice : ");
		
	}
}
