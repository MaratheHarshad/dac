package com.app.core;

import java.time.LocalDate;

public class Cloth {

	static int idGenerator;

//	Cloth Attributes

	int id;
	Category cat;
	int stock;
	LocalDate stockUpdateDate;
	Size size;
	double price;
	Brand brand;
	String color;
	double discount;

	// initializing static variable to generate unique id's for each entry
	static {
		idGenerator = 1;
	}
	
	
	
	
//	parameterized constructor to create new entry of cloth

	public Cloth(Category cat, int stock, LocalDate stockUpdateDate, Size size, double price, Brand brand, String color,
			double discount) {
		
		this.id = Cloth.idGenerator++;
		this.cat = cat;
		this.stock = stock;
		this.stockUpdateDate = stockUpdateDate;
		this.size = size;
		this.price = price;
		this.brand = brand;
		this.color = color;
		this.discount = discount;
	}

	
	
	public int getId() {
		return id;
	}





	@Override
	public String toString() {
		return "Cloth [id=" + id + ", cat=" + cat + ", stock=" + stock + ", stockUpdateDate=" + stockUpdateDate
				+ ", size=" + size + ", price=" + price + ", brand=" + brand + ", color=" + color + ", discount="
				+ discount + "]";
	}
	
	
	
//	Getters and Setters

	public Category getCat() {
		return cat;
	}

	public void setCat(Category cat) {
		this.cat = cat;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public LocalDate getStockUpdateDate() {
		return stockUpdateDate;
	}

	public void setStockUpdateDate(LocalDate stockUpdateDate) {
		this.stockUpdateDate = stockUpdateDate;
	}

	public Size getSize() {
		return size;
	}

	public void setSize(Size size) {
		this.size = size;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public double getDiscount() {
		return discount;
	}

	public void setDiscount(double discount) {
		this.discount = discount;
	}

}
