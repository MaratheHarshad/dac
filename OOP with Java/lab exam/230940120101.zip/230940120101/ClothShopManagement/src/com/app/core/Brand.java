package com.app.core;

public enum Brand {
	
	VAN_HEUSEN, PUMA, LEE

}
