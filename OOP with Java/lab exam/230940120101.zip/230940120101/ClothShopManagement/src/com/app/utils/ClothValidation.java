package com.app.utils;


import java.time.LocalDate;
import java.util.List;


import com.app.core.Brand;
import com.app.core.Category;
import com.app.core.Cloth;
import com.app.core.Size;
import com.app.exceptions.DuplicateEntryException;
import com.app.exceptions.InvalidArgumentException;
import com.app.exceptions.InvalidIdException;

public interface ClothValidation {

//	method to validate all the inputs to create new Cloth object

	public static Cloth validateAll(String cat, int quantity, String stringSize, double price, String stringBrand,
			String color, double discounts, List<Cloth> clothList) throws InvalidArgumentException, DuplicateEntryException {

		Category category = validateCategory(cat);
		validateQuantity(quantity);
		Size size = validateSize(stringSize);
		Brand brand = validateBrand(stringBrand);

		validateDup(category, brand, size, clothList);
		
		return new Cloth(category, quantity, LocalDate.now(), size, price, brand, color, discounts);
		
	}

	// validate if (cloth with same category, brand, size already exist)
	public static void validateDup(Category category, Brand brand, Size size, List<Cloth> clothList) throws DuplicateEntryException{
		
		for(Cloth cloth : clothList) {
			if(cloth.getCat().equals(category) && cloth.getBrand().equals(brand) && cloth.getSize().equals(size)) {
				throw new DuplicateEntryException("cloth with same category, brand and size already exist");
			}
		}
		

	}

	
//	validate enum types
	
	public static Brand validateBrand(String stringBrand) {
		return Brand.valueOf(stringBrand.toUpperCase());
	}

	public static Size validateSize(String s) {
		return Size.valueOf(s.toUpperCase());
	}

	public static Category validateCategory(String cat) {
		return Category.valueOf(cat.toUpperCase());
	}

//	validate quantity (if less than 0 , throw exception)

	public static void validateQuantity(int quantity) throws InvalidArgumentException {

		if (quantity < 1) {
			throw new InvalidArgumentException("quantity cannot be less than 1");
		}
	}
	
	
	public static Cloth validateAndFindCloth(int clothId, List<Cloth> clothList) throws InvalidIdException {
		
		for(Cloth cloth : clothList) {
			if(cloth.getId() == clothId) {
				return cloth;
			}
		}
		
//		if cloth with same id does not found
		throw new InvalidIdException("cloth id is invalid");
		
		
		
	}

}
