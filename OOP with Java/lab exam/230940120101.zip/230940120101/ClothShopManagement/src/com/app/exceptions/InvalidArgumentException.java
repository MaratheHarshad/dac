package com.app.exceptions;

// extends from Exception (checked exception)

public class InvalidArgumentException extends Exception {
	
	public InvalidArgumentException(String errMsg) {
		super(errMsg);
	}

}
