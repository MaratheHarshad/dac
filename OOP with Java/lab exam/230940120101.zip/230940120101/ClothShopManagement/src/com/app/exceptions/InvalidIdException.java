package com.app.exceptions;

public class InvalidIdException extends Exception {

	public InvalidIdException(String errMsg) {
		super(errMsg);
	}
}
