package com.app.utils;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.app.core.Brand;
import com.app.core.Category;
import com.app.core.Cloth;
import com.app.core.Size;
import com.app.exceptions.InvalidIdException;

import static com.app.utils.ClothValidation.*;

public interface ClothUtils {
	
	public static List<Cloth> populateList(){
		
		List<Cloth> list = new ArrayList<>();
		
		list.add(new Cloth(Category.MENS_TSHIRT, 200, LocalDate.of(2023, 4, 20), Size.M, 1500, Brand.PUMA, "red", 20));
		list.add(new Cloth(Category.MENS_TSHIRT, 150, LocalDate.of(2023, 6, 23), Size.L, 1600, Brand.LEE, "green", 20));
		list.add(new Cloth(Category.MENS_SHIRTS, 50, LocalDate.now(), Size.XL, 2000, Brand.PUMA, "white", 20));
		list.add(new Cloth(Category.MENS_SHIRTS, 30, LocalDate.of(2022, 1, 15), Size.L, 1500, Brand.LEE, "blue", 20));
		list.add(new Cloth(Category.WOMENS_JEANS, 40, LocalDate.of(2023, 10, 1), Size.XL, 4500, Brand.VAN_HEUSEN, "white", 20));
		list.add(new Cloth(Category.WOMENS_JEANS, 20, LocalDate.now(), Size.L, 3000, Brand.LEE, "black", 20));
		
		return list;
		
		
	}
	
	public static Cloth validateAndUpdateStock(int clothId, int stock, List<Cloth> clothList) throws InvalidIdException {
		
		Cloth cloth = validateAndFindCloth(clothId, clothList);
		
		cloth.setStock(stock);
		cloth.setStockUpdateDate(LocalDate.now());
		
		return cloth;
		
		
	}
	
	public static void updateDiscount(double discount, String cat, String br, List<Cloth> clothList) {
		
		Category category = validateCategory(cat);
		Brand brand = validateBrand(br);
		
		clothList.forEach(cloth -> {
			if(cloth.getCat() == category && cloth.getBrand() == brand) {
				cloth.setDiscount(discount);
			} 
		});
		
	}
	

}
