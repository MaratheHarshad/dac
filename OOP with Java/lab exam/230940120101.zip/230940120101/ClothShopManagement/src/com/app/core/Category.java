package com.app.core;

public enum Category {
	
	MENS_TSHIRT, MENS_SHIRTS, WOMENS_JEANS

}
