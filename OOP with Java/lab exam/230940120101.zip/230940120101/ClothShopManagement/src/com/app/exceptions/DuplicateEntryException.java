package com.app.exceptions;

public class DuplicateEntryException extends Exception {
	public DuplicateEntryException(String errMsg) {
		super(errMsg);
	}
}
