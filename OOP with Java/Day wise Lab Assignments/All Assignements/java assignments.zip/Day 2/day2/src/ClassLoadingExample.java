public class ClassLoadingExample{

	public static void main(String[] args){
		A a;
	}
}

class A{
	int a;
}
