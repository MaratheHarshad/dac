// exports -> pre build object available

// dynamically inserting new properties

// function addition(x, y) {
//   return x + y;
// }

exports.addition = function (x, y) {
  return x + y;
};
