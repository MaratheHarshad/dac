function add(x, y) {
  return x + 6;
}

// To print the error in the console, increase the readability of code ()
console.error("This is error message");

console.log(add(5, 6));

// module

// any file in which we write javascript code is called as module
