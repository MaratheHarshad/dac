const m3 = require("./module3");

m3.function1();
m3.function2();
m3.function3();
