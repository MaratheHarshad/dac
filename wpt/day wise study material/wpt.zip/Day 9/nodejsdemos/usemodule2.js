const m2 = require("./module2");

var n = m2.combination(4, 3);

console.log("combination: " + n);
console.log(m2.user);
