const m1 = require("./module1");

// ./ -> used when it is user defined  module (built in module)
// all the functions inside that module are now available

console.log(m1.addition(5, 8));
