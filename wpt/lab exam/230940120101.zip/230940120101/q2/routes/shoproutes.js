const express = require("express")

// router instance 
const router = express.Router();

// from products data handler module
const { addNewProduct, getAllProducts , getNewProduct} = require("../shopdata/productList")

// route to handle, add new product
// http://localhost:9090/new

router.post("/new", (req,res)=>{

    const { ProductId, ProductName, Price, ExpiryDate } = req.body;

    console.log(req.body);

    addNewProduct(ProductId, ProductName, Price, ExpiryDate);

    res.status(201).send(getNewProduct());
})

// route to return all the products 
// http://localhost:9090/list

router.get("/list", (req, res)=>{

    res.status(200).send(getAllProducts());
})



// exports is a global object available that allow us to export the functions, objects
module.exports = router;