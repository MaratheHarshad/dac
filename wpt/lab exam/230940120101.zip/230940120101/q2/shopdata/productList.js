const products = [];

const getAllProducts = ()=>{
    return products;
}

const getNewProduct = ()=> {
    return products[products.length - 1]
}

const addNewProduct = ( ProductId, ProductName, Price, ExpiryDate) => {

    // parse the Id, Price
    // parse the Expiray date from string to date

    

    ProductId = parseInt(ProductId);
    Price = parseFloat(Price);
     
    // parse the Expiry Date, from string to date

    
    ExpiryDate = new Date(ExpiryDate).toLocaleDateString();


    const newProduct = {
        ProductId,
        ProductName,
        Price,
        ExpiryDate
    }

    products.push(newProduct);

    console.log("new product inserted")
}


module.exports = { addNewProduct , getAllProducts, getNewProduct}