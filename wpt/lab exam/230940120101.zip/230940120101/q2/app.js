// import require modules
const express = require("express")
const cors = require("cors")

const shoprouter = require("./routes/shoproutes")


const app = express();

const PORT = 9090;


// configure middlewares

app.use(express.urlencoded({extended : false}))
app.use(express.json());

// allow cors
app.use(cors())

// define routes
app.use("/", shoprouter)

// start the server on PORT 9090, using express instance

app.listen(PORT, ()=>{
    console.log("server started")
    console.log(`http://localhost:${PORT}`)
})


