import React from 'react'

function ProductList({products}) {
  return (


    <div>
        {products.length > 0 && 
        <table className="table">
  <thead className="thead-light">
    <tr>
      <th scope="col">Product Id</th>
      <th scope="col">Product Name</th>
      <th scope="col">Price</th>
      <th scope="col">Product Expiry Date</th>
    </tr>
  </thead>
  <tbody>

    {products.map((product, index)=>(
        <tr key={index}>
            <td>{product.ProductId}</td>
            <td>{product.ProductName}</td>
            <td>{product.Price}</td>
            <td>{product.ExpiryDate}</td>
            
        </tr>
    ))}
    
  </tbody>
</table>
}

    </div>
  )
}

export default ProductList