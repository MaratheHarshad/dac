import React, { useState } from 'react'
import axios from "axios"

// import css
import './AddProduct.css';

function AddProduct(props) {


    // state to manage form details 

    const [formdetails, setFormDetails ] = useState({ProductId : "", ProductName : "", Price : "", ExpiryDate : ""})

    const [successMessage, setSuccessMessage] = useState("");
    const [errorMessage, setErrorMessage] = useState("");

    // function to handle change on input types
    // update the state, for 2 way binding
    const handlechange = (e)=>{ 

        // object destructuring
        // which attribute has to changed with which value in formdetails state
        const {name, value} = e.target;

        setFormDetails({...formdetails, [name] : value})

        // set error message state as empty
        setErrorMessage("")
    }


    // function to validate input data and send the data in the server side
    const addProduct = ()=>{

        const {ProductId, ProductName,Price, ExpiryDate} = formdetails

        if(ProductId.length < 1 || ProductName.length < 1 || Price.length < 1 || ExpiryDate.length < 1){

            setErrorMessage("Please fill all the details")
            return;
        }

        // else add the product in the server , and updat the state accordingly and reset the form

        // make a post request on server

        const url = "http://localhost:9090/new"

        axios.post(url, {
            ProductId , ProductName , Price , ExpiryDate 
        }).then((res)=>{
            console.log(res)
            // reset the formdetails
            setFormDetails({ProductId : "", ProductName : "", Price : "", ExpiryDate : ""})

            // update the table, and show message to url , product inserted

            setSuccessMessage("product successfully inserted")

            // add newly inserted product in the products list

            setTimeout(()=>{
                setSuccessMessage("");
            }, 2000)

            props.products.push(res.data)
            props.setProducts([...props.products])


        }).catch((err)=>{
            console.log("error while sending data to the server")
        })
        

        


        
    }


  return (
    <div id='add-product-form'>
        <form>
            <p id='error-message'>{errorMessage}</p>
            <p id='success-message' >{successMessage}</p>
  <div className="form-group">
    <label htmlFor="productId">Product Id</label>
    <input type="number" className="form-control" id="productId"  name='ProductId' value={formdetails.ProductId} onChange={handlechange}/>
    
  </div>

  <div className="form-group">
    <label htmlFor="productName">Product Name</label>
    <input type="text" className="form-control" id="productName" name='ProductName' value={formdetails.ProductName} onChange={handlechange}/>
    
  </div>

  <div className="form-group">
    <label htmlFor="price">Price</label>
    <input type="number" className="form-control" id="price" name='Price' value={formdetails.Price} onChange={handlechange}/>
    
  </div>

  <div className="form-group">
    <label htmlFor="expiryDate">Expiry Date</label>
    <input type="date" className="form-control" id="expiryDate" name='ExpiryDate' value={formdetails.ExpiryDate} onChange={handlechange} />
    
  </div>
  
  
  <button type="button" className="btn btn-primary" onClick={addProduct}>Add Product</button>
</form>
    </div>
  )
}

export default AddProduct