// import './App.css';
import "./style.css"
import AddProduct from './components/AddProduct';
import ProductList from './components/ProductList';

import axios from "axios"

// import bootstrap css

import "bootstrap/dist/css/bootstrap.min.css"
import { useState, useEffect } from "react";




function App() {
  // state for products list
  const [products, setProducts] = useState([]);
  
useEffect(()=>{



  // make a get request and populate the products list

  const url = "http://localhost:9090/list"
  axios.get(url).then((res)=>{
    setProducts(res.data);
  }).catch((err)=>{
    console.log("error occur while fetching the products list")
  })
}, [])


  return (
    <div className="App" id="app">
      <div>
        <AddProduct  products={products} setProducts={setProducts}/>

      </div>
      <div>
        <ProductList products={products} setProducts={setProducts}/>

      </div>
    </div>
  );
}

export default App;
